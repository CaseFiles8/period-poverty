extends CanvasLayer

signal dialogue_finished

enum State {
	READY,
	READING,
	FINISHED
}

const CHAR_RATE = 0.075

@onready var label = $Textboxalicious/Panel/MarginContainer/Panel/Label
@onready var bg = $Textboxalicious/Panel

var tween: Tween
var state: State

var pads_found = 0
var dialogue_queue = []


func _ready():
	randomize()
	_hide()
	state = State.READY


func _process(_delta):

	if Input.is_action_just_pressed("ui_select"):

		match state:

			State.READY:
				# INTRO DIALOGUE (2 lines now)
				start_dialogue([
					"welcome to period poverty!",
					"you're tanvi, and you're... really broke. find 4 pads before you leak!"
				])

			State.READING:
				_finish()

			State.FINISHED:

				_hide()

				if dialogue_queue.size() > 0:
					_display_dialogue(dialogue_queue.pop_front())
				else:
					state = State.READY
					show_pad_result()


func _hide():
	label.text = ""
	label.visible_ratio = 0
	bg.visible = false


func _show():
	bg.visible = true
	tween = create_tween()
	tween.finished.connect(_finish)


func _finish():
	if tween:
		tween.kill()

	label.visible_ratio = 1
	state = State.FINISHED


func start_dialogue(lines):
	dialogue_queue = lines
	_display_dialogue(dialogue_queue.pop_front())


func _display_dialogue(lines):

	label.text = lines
	label.visible_ratio = 0

	_show()

	tween.tween_property(label, "visible_ratio", 1.0, len(lines) * CHAR_RATE)

	state = State.READING


func show_pad_result():

	var chance = randf()

	if chance <= 0.3:

		pads_found += 1

		# WIN CONDITION
		if pads_found >= 4:
			start_dialogue([
				"you found the last pad! you win!",
				"you got lucky! the chances of finding a pad in a public restroom are 30% 
				worldwide. go to period.org to learn more."
			])
			pads_found = 0
			return

		# RANDOM WARNING MESSAGE
		var warnings = [
			"you better hurry! you might leak...",
			"uh oh! you're broke, hurry to find your next pad before it's too late."
		]

		var warning = warnings[randi() % warnings.size()]

		start_dialogue([
			"you found a pad! (" + str(pads_found) + "/4)",
			warning
		])

	else:

		start_dialogue(["there are no pads in this restroom :("])
